package com.atos.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtosDevBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtosDevBackendApplication.class, args);
	}

}
