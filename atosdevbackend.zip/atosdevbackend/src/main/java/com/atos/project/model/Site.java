package com.atos.project.model;

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

@Entity
@Table(name="site")
@EntityListeners(AuditingEntityListener.class)
public class Site {
	// les attributs et mappages de liaisons vers les autres tables
    @Id
//    @Column(name="id_sit")
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class, MyJsonView.Contact.class})
    private Integer idSit;



    @Size(max = 100)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class, MyJsonView.Contact.class})
    private String lib;

    @Size(max = 100)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class})
    private String adr;

    @Size(max = 100)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class})
    @Column(name ="code_postal")
    private String codePostal;

    @Size(max = 100)
    @Email
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class})
    private String email;

    @Size(max = 100)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class})
    private String tel1;

    @Size(max = 100)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class})
    private String tel2;

    @Size(max = 100)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class})
    private String fax;

    @Size(max = 100)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Besoin.class})
    private String ville;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "idclient")
    @JsonView({MyJsonView.Client.class,MyJsonView.Besoin.class, MyJsonView.SiteClient.class})
    private Client clientSite;

    // le constructeur par défaut sera généré implicitement
    
    
    // les getters et setters
    public Integer getIdSit() {
        return idSit;
    }

    public void setIdSit(Integer idSit) {
        this.idSit = idSit;
    }

    public String getLib() {
        return lib;
    }

    public void setLib(String lib) {
        this.lib = lib;
    }

    public String getAdr() {
        return adr;
    }

    public void setAdr(String adr) {
        this.adr = adr;
    }

    public String getCodePostal() {
        return codePostal;
    }

    public void setCodePostal(String codePostal) {
        this.codePostal = codePostal;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTel1() {
        return tel1;
    }

    public void setTel1(String tel1) {
        this.tel1 = tel1;
    }

    public String getTel2() {
        return tel2;
    }

    public void setTel2(String tel2) {
        this.tel2 = tel2;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public Client getClientSite() {
        return clientSite;
    }

    public void setClientSite(Client clientSite) {
        this.clientSite = clientSite;
    }
}
