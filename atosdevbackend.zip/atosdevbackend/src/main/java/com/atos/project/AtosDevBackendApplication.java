package com.atos.project;

/**
 * Classe principale - point d'entrée de l'API (Application Program Interface) grâce à l'annotation @SpringBootApplication
 * et à la méthode main()
 * @EnableSwagger2 - sert à générer de manière automatique de la documentation (au format HTML ou JSON) conçernant notre application
 * 
 */


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class AtosDevBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtosDevBackendApplication.class, args);
	}

}
