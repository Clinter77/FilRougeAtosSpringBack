package com.atos.project.model;


import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

@Entity
@Table(name = "Besoin")
@EntityListeners(AuditingEntityListener.class)
public class Besoin {

	// les attributs
    @Column(name = "id_bsn")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.Proposition.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,


    })
    private Integer id;

    @Column(name = "d_debut")
    @Temporal(TemporalType.DATE)
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,
            MyJsonView.Proposition.class,

    })
    Date d_debut;

    /**
     * @Size : pour définir une contrainte sur la taille à respecter
     */
    @Column(name = "intitule")
    @Size(max = 250)
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,
            MyJsonView.Proposition.class,

    })
    private String intitule;

    @Column(name = "d_echeance")
    @Temporal(TemporalType.DATE)
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,
            MyJsonView.Proposition.class,

    })
    Date d_echeance;

    // Site
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "idSit")
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Proposition.class,

    })
    private Site site;

    // le mappage de liaison vers la table contact-client
    @ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "id_ctc")
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.Contact.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Proposition.class,

    })
    private ContactClient contactClient;

    // ts (timestamp) - la date de dernière modification enregistrée
    @CreationTimestamp
    @Column(name = "ts")
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,
            MyJsonView.Proposition.class,

    })
    private Date ts;

    /*@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "id_usr")
    @JsonView({MyJsonView.Besoin.class, MyJsonView.Utilisateur.class, MyJsonView.BesoinCompetence.class })
    private User user;*/

    @Column(name = "remarque")
    @Size(max = 1000)
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,
            MyJsonView.Proposition.class,

    })
    private String remarque;

    @Column(name = "f_cloture")
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,
            MyJsonView.Proposition.class,
    })
    private boolean fCloture;


    @Column(name = "f_recurent")
    @JsonView({
            MyJsonView.Besoin.class,
            MyJsonView.BesoinCompetence.class,
            MyJsonView.Client.class,
            MyJsonView.Proposition.class,
    })
    private boolean fRecurent;

    // le constructeur par défaut est non codé, il est généré implicitement par l'IDE
   
    // les Getters et Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getD_debut() {
        return d_debut;
    }

    public void setD_debut(Date d_debut) {
        this.d_debut = d_debut;
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    public Date getD_echeance() {
        return d_echeance;
    }

    public void setD_echeance(Date d_echeance) {
        this.d_echeance = d_echeance;
    }

    public Site getSite() {
        return site;
    }

    public void setSite(Site site) {
        this.site = site;
    }

    public ContactClient getContactClient() {
        return contactClient;
    }

    public void setContactClient(ContactClient contactClient) {
        this.contactClient = contactClient;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    /*public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }*/

    public String getRemarque() {
        return remarque;
    }

    public void setRemarque(String remarque) {
        this.remarque = remarque;
    }

    public boolean isfCloture() {
        return fCloture;
    }

    public void setfCloture(boolean fCloture) {
        this.fCloture = fCloture;
    }

    public boolean isfRecurent() {
        return fRecurent;
    }

    public void setfRecurent(boolean fRecurent) {
        this.fRecurent = fRecurent;
    }


}
