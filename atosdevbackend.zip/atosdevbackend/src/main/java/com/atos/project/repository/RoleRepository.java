package com.atos.project.repository;

import java.util.Optional;

import com.atos.project.model.ERole;
import com.atos.project.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Cette interface Repository hérite de (étend) l'interface JpaRepository pour la communication DAO (avec la BDD) 
 * @author-JavaDoc Christophe
 *
 */

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(ERole name);
}
