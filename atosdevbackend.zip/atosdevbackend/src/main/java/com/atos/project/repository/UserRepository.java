package com.atos.project.repository;

import java.util.Optional;

import com.atos.project.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 
 * @author JavaDoc - Christophe
 * cette interface UserRepository étend JpaRepository pour la communication avec la BDD (DAO)
 * et servira pour récupérer l'username (via la méthode findByUsername()), puis de s'assurer (via les méthodes existsByUsername(), et existsByEmail()) 
 * que l'user de type User a bien effectivement renseigné un Username et un E-mail
 */

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);

    Boolean existsByUsername(String username);

    Boolean existsByEmail(String email);
}