package com.atos.project.payload.request;

import java.util.Set;

import javax.validation.constraints.*;

/**
 * @author JavaDoc - Christophe
 * Cette classe sert à pouvoir récupérer et conserver les username, email, role, et password, une fois le Token généré
 * et la connexion établie
 *
 */

public class SignupRequest {
	// les attributs
    @NotBlank
    @Size(min = 3, max = 20)
    private String username;

    @NotBlank
    @Size(max = 50)
    @Email
    private String email;

    // cette collection Java (Set) n'admet pas les doublons, et est utilisable grâce à l'import de la bibliothèque java.util.Set
    private Set<String> role;

    @NotBlank
    @Size(min = 6, max = 40)
    private String password;

    // les getters et setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<String> getRole() {
        return this.role;
    }

    public void setRole(Set<String> role) {
        this.role = role;
    }
}
