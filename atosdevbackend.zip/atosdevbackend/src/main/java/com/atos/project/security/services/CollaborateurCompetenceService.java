package com.atos.project.security.services;

import com.atos.project.model.Collaborateur;
import com.atos.project.model.CollaborateurCompetence;
import com.atos.project.repository.CollaborateurCompetenceRepo;
import com.atos.project.repository.CollaborateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Nos classes de Services servent toutes à assurer la liaison entre le contrôleur d'une entité donnée
 * et son entité Repository (qui hérite de JPA) - Ceci afin de remonter vers la Base De Données (BDD),
 * pour assurer la communication DAO,
 * et pouvoir utiliser les requêtes ORM
 * 
 * findAll() : méthode CRUD-ORM pour récupérer une liste d'une entité
 * save() : méthode CRUD-ORM pour un ajout (cas du PostMapping) ou pour une modification (cas du PutMapping)
 * findById() : méthode CRUD-ORM pour récupérer les informations détaillées sur une entité donnée
 * deleteById() : méthode CRUD-ORM pour supprimer une entité
 * 
 * @author-JavaDoc Christophe
 *
 */

@Service
public class CollaborateurCompetenceService {

    @Autowired
    CollaborateurCompetenceRepo collaborateurCompetenceRepo;

    /*Lister tous les collaborateurs*/
    public List<CollaborateurCompetence> getAll() {
        return this.collaborateurCompetenceRepo.findAll();
    }

    public CollaborateurCompetence addCollaborateurCompetence(CollaborateurCompetence collaborateurCompetence) {
        return this.collaborateurCompetenceRepo.save(collaborateurCompetence);
    }

    public CollaborateurCompetence findById(Integer id) {
        return this.collaborateurCompetenceRepo.findById(id).get();
    }

    public List<CollaborateurCompetence> findAll() {
        return this.collaborateurCompetenceRepo.findAll();
    }

    public CollaborateurCompetence save(CollaborateurCompetence collaborateurCompetence) {
        return this.collaborateurCompetenceRepo.save(collaborateurCompetence);
    }

    public void delete(Integer id) {
        this.collaborateurCompetenceRepo.deleteById(id);
    }
}
