package com.atos.project.model;

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

@Entity
@Table(name = "Client")
@EntityListeners(AuditingEntityListener.class)
public class Client {
	// les attributs et mappages de liaisons
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class, MyJsonView.SiteClient.class})
    private Integer idClient;

    /**
     * La contrainte de taille à respecter pour ce champ est à 100 caractères
     */
    @Size(max = 100)
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class, MyJsonView.SiteClient.class})
    private String lib;

    @Size(max = 100)
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class,MyJsonView.SiteClient.class})
    private String adr;

    @Size(max = 100)
    @Column(name ="code_postal")
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class, MyJsonView.SiteClient.class})
    private String codePostal;

    // en plus du critère de taille (@Size max à 100 caractères),
    // @Email : un autre critère à respecter pour validation, ce champ doit ressembler à une adresse e-mail
    @Size(max = 100)
    @Email
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class, MyJsonView.SiteClient.class})
    private String email;

    @Size(max = 100)
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class, MyJsonView.SiteClient.class})
    private String tel1;

    @Size(max = 100)
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class,MyJsonView.SiteClient.class})
    private String fax;

    @Size(max = 100)
    @JsonView({MyJsonView.Besoin.class,MyJsonView.Client.class,MyJsonView.SiteClient.class})
    private String ville;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name= "idbsn")
    @JsonView({MyJsonView.Client.class, MyJsonView.SiteClient.class})
    private Besoin besoinClient;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name= "idprops")
    @JsonView({MyJsonView.Client.class, MyJsonView.SiteClient.class, MyJsonView.Besoin.class})
    private Proposition props;

    // les deux constructeurs
    public Client() {}

    public Client(Integer idClient, String lib, String adr,  String codePostal,  String email, String tel1,  String fax,  String ville) {
        this.idClient = idClient;
        this.lib = lib;
        this.adr = adr;
        this.codePostal = codePostal;
        this.email = email;
        this.tel1 = tel1;
        this.fax = fax;
        this.ville = ville;
    }


    // les Getters et Setters
    public Integer getIdClient() {
        return idClient;
    }

    public void setIdClient(Integer idClient) {
        this.idClient = idClient;
    }

    public String getLib() {
        return lib;
    }

    public void setLib(String lib) {
        this.lib = lib;
    }

    public String getAdr() {
        return adr;
    }

    public void setAdr(String adr) {
        this.adr = adr;
    }

    public String getCodePostal() {
        return codePostal;
    }

    public void setCodePostal(String codePostal) {
        this.codePostal = codePostal;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTel1() {
        return tel1;
    }

    public void setTel1(String tel1) {
        this.tel1 = tel1;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }


    public Besoin getBesoinClient() {
        return besoinClient;
    }

    public void setBesoinClient(Besoin besoinClient) {
        this.besoinClient = besoinClient;
    }
}
