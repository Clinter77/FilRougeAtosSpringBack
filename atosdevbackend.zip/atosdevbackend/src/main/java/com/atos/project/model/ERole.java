package com.atos.project.model;

// une énumération pour les différents rôles (Moderator correspond au rôle consultant)

public enum ERole {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_ADMIN,
    ROLE_MANAGER

}
