package com.atos.project.controllers;

import com.atos.project.model.ContactClient;
import com.atos.project.security.services.ContactService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@RestController
@CrossOrigin
public class ContactController {
    
    ContactService contactService;
    
    @Autowired
    public ContactController(final ContactService contactService) {
        this.contactService = contactService;
    }

    /*******************************************************
     *         Liste de tous les contacts-clients          *
     *******************************************************/
    @GetMapping("/ctc")
    @JsonView(MyJsonView.Contact.class)
    public List<ContactClient> showContactClient() {
        return this.contactService.findAll();
    }

    @GetMapping("/ctc/{id}")
    @JsonView(MyJsonView.Contact.class)
    public ContactClient getcontact(@PathVariable int id) {
        return (ContactClient) this.contactService.findById(id);
    }


    /*******************************************************
     *                    Ajout d'un contact-client        *
     *******************************************************/
    @PutMapping("/addCtc")
    @JsonView(MyJsonView.Contact.class)
    public ContactClient addContact(@RequestBody ContactClient contacts) {
        return this.contactService.save(contacts);
    }

    /*******************************************************
     *               Suppression d'un contact-client       *
     *******************************************************/
    @DeleteMapping("/delCtc/{id}")
    @JsonView(MyJsonView.Contact.class)
    public void delete(@PathVariable int id) {
        this.contactService.delete(id);
    }
}
