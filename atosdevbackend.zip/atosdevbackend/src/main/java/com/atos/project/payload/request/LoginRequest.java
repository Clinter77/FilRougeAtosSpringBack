package com.atos.project.payload.request;

import javax.validation.constraints.NotBlank;

/**
 * @author JavaDoc - Christophe
 * cette classe sert pour récupérer les username et password lors de la requête (dans le processus d'authentification
 * et de génération du Token)
 */

public class LoginRequest {
	// les attributs
    @NotBlank
    private String username;

    @NotBlank
    private String password;

    // les getters et setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
