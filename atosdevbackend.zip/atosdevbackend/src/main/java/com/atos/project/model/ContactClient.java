package com.atos.project.model;

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

@Entity
@Table(name="contact_client")
@EntityListeners(AuditingEntityListener.class)

public class ContactClient {
	// les attributs
    @Id
    @Column(name="id_ctc")
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private Integer id;

    // @Size(max = 100) : pour la contrainte sur la taille du champ à respecter
    @Size(max = 100)
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private String nom;

    @Size(max = 100)
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private String prenom;

    @Size(max = 100)
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private String poste;

    @Size(max = 100)
    @Email
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private String email;

    @Size(max = 100)
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private String tel1;

    @Size(max = 100)
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private String tel2;

    @Size(max = 100)
    @JsonView({MyJsonView.Contact.class, MyJsonView.Besoin.class, MyJsonView.BesoinCompetence.class})
    private String fax;

    // les mappages de liaisons vers les autres tables
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name="id_sit")
    @JsonView({MyJsonView.Contact.class, MyJsonView.BesoinCompetence.class})
    private Site site;

    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH}, fetch=FetchType.LAZY)
    @JoinTable(
            name = "contact_competence",
            joinColumns = @JoinColumn(name = "id_ctc"),
            inverseJoinColumns = @JoinColumn(name = "id_cpc"))
    @JsonView({MyJsonView.Contact.class})
    Set<Competence> listeCompetence;

    // le constructeur par défaut, non défini, le sera de façon automatique
    
    // les getters et setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getPoste() {
        return poste;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTel1() {
        return tel1;
    }

    public void setTel1(String tel1) {
        this.tel1 = tel1;
    }

    public String getTel2() {
        return tel2;
    }

    public void setTel2(String tel2) {
        this.tel2 = tel2;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public Site getSite() {
        return site;
    }

    public void setSite(Site site) {
        this.site = site;
    }

    public Set<Competence> getListeCompetence() {
        return listeCompetence;
    }

    public void setListeCompetence(Set<Competence> listeCompetence) {
        this.listeCompetence = listeCompetence;
    }

}
