package com.atos.project.model;

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

@Entity
@Table(name = "competence")
@EntityListeners(AuditingEntityListener.class)
public class Competence {
	// les attributs
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonView({
            MyJsonView.Competence.class,
            MyJsonView.Collaborateur.class,
            MyJsonView.CollaborateurCompetence.class,
            MyJsonView.Contact.class,
            MyJsonView.BesoinCompetence.class
    })
    private Integer idCpc;

    @Column(unique = true)
    @JsonView({
            MyJsonView.Competence.class,
            MyJsonView.Collaborateur.class,
            MyJsonView.CollaborateurCompetence.class,
            MyJsonView.Contact.class,
            MyJsonView.BesoinCompetence.class
    })
    private String lib;

    // les mappages de liaisons vers les autres tables
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "idTcp")
    @JsonView({MyJsonView.Competence.class, MyJsonView.BesoinCompetence.class})
    private TypeCompetence typeCompetence;

    @ManyToMany(mappedBy = "listeCompetence",cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JsonView({MyJsonView.Competence.class, MyJsonView.BesoinCompetence.class})
    Set<ContactClient> listeContactClient;
/*    @ManyToMany
      @JoinTable(
              name = "contact_competence",
              joinColumns = @JoinColumn(name = "id_cpc"),
              inverseJoinColumns = @JoinColumn(name = "id_ctc"))
      Set<ContactClient> listeContactClient; */

    // le constructeur par défaut n'a pas été défini, il sera généré automatiquement de façon implicite
    
    // les getters et setters
    public Integer getIdCpc() {
        return idCpc;
    }

    public void setIdCpc(Integer idCpc) {
        this.idCpc = idCpc;
    }

    public String getLib() {
        return lib;
    }

    public void setLib(String lib) {
        this.lib = lib;
    }

    public TypeCompetence getTypeCompetence() {
        return typeCompetence;
    }

    public void setTypeCompetence(TypeCompetence typeCompetence) {
        this.typeCompetence = typeCompetence;
    }

    public Set<ContactClient> getListeContactClient() {
        return listeContactClient;
    }

    public void setListeContactClient(Set<ContactClient> listeContactClient) {
        this.listeContactClient = listeContactClient;
    }


}