package com.atos.project.model;

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

// les contraintes à respecter (pour validation), il faut impérativement renseigner un Username et un email
@Entity
@Table(name = "users",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = "username"),
                @UniqueConstraint(columnNames = "email")
        })
public class User {

	// les attributs
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonView({MyJsonView.Utilisateur.class, MyJsonView.Besoin.class})
    private Long id;

    // @NotBlank : contrainte de valeur non nulle
    // @Size : contrainte sur la taille du champ à respecter
    @NotBlank
    @Size(max = 20)
    @JsonView(MyJsonView.Utilisateur.class)
    private String username;

    @NotBlank
    @Size(max = 50)
    @Email
    @JsonView(MyJsonView.Utilisateur.class)
    private String email;

    @NotBlank
    @Size(max = 120)
    @JsonView(MyJsonView.Utilisateur.class)
    private String password;

    // les mappages de liaisons vers les autres tables
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinTable(name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    @JsonView(MyJsonView.Utilisateur.class)
    private Set<Role> roles = new HashSet<>();

    /*@OneToMany(mappedBy = "user")
    @JsonView({MyJsonView.Utilisateur.class, MyJsonView.Besoin.class})
    private Set<Besoin> bsn = new HashSet<>();*/

    // les deux constructeurs
    public User() {
    }

    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    // les getters et setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

}
