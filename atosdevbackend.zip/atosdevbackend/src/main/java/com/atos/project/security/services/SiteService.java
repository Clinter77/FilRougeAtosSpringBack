package com.atos.project.security.services;

import com.atos.project.model.Site;
import com.atos.project.repository.SiteRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Nos classes de Services servent toutes à assurer la liaison entre le contrôleur d'une entité donnée
 * et son entité Repository (qui hérite de JPA) - Ceci afin de remonter vers la Base De Données (BDD),
 * pour assurer la communication DAO,
 * et pouvoir utiliser les requêtes ORM
 * 
 * findAll() : méthode CRUD-ORM pour récupérer une liste d'une entité
 * save() : méthode CRUD-ORM pour un ajout (cas du PostMapping) ou pour une modification (cas du PutMapping)
 * findById() : méthode CRUD-ORM pour récupérer les informations détaillées sur une entité donnée
 * deleteById() : méthode CRUD-ORM pour supprimer une entité
 * 
 * @author-JavaDoc Christophe
 *
 */

@Service
public class SiteService {
    
    @Autowired
    SiteRepo siteRepo;

    /*Lister tous les sites*/
    public List<Site> getAll() {
        return this.siteRepo.findAll();
    }

    public Site addSite(Site site) {
        return this.siteRepo.save(site);
    }

    public Site findById(Integer id) {
        return this.siteRepo.findById(id).get();
    }

    public List<Site> findAll() {
        return this.siteRepo.findAll();
    }

    public Site save(Site site) {
        return this.siteRepo.save(site);
    }

    public void delete(Integer id) {
        this.siteRepo.deleteById(id);
    }
}
