package com.atos.project.repository;

import com.atos.project.model.Agence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Cette interface Repository hérite de (étend) l'interface JpaRepository pour la communication DAO (avec la BDD) 
 * @author-JavaDoc Christophe
 *
 */

@Repository
public interface AgenceRepository extends JpaRepository<Agence, Integer> {
}
