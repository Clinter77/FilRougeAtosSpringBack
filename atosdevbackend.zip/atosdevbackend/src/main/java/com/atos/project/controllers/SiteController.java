package com.atos.project.controllers;

import com.atos.project.model.Site;
import com.atos.project.security.services.SiteService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@RestController
@CrossOrigin
public class SiteController {
    
    SiteService siteService;

    public SiteController(final SiteService siteService) {
        this.siteService = siteService;
    }

    /*******************************************************
     *                      Liste des sites
     *******************************************************/
    @GetMapping("/site")
    @JsonView(MyJsonView.SiteClient.class)
    public List<Site> showSite() {
        return this.siteService.findAll();
    }

    @GetMapping("/site/{id}")
    @JsonView(MyJsonView.SiteClient.class)
    public Site getsite(@PathVariable int id) {
        return (Site) this.siteService.findById(id);
    }


    /*******************************************************
     *                     Ajout de site
     *******************************************************/
    @PutMapping("/addSit")
    @JsonView(MyJsonView.SiteClient.class)
    public Site addSite(@RequestBody Site sites) {
        return this.siteService.save(sites);
    }

    /******************************************************
     *                      Suppression d'un site
     *******************************************************/

    @DeleteMapping("/delSit/{id}")
    @JsonView(MyJsonView.SiteClient.class)
    public void delete(@PathVariable int id) {
        this.siteService.delete(id);
    }
}

