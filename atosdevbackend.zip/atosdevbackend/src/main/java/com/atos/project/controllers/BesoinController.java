package com.atos.project.controllers;

import com.atos.project.model.Besoin;
import com.atos.project.security.services.BesoinService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@CrossOrigin
@RestController
public class BesoinController {
    
    BesoinService besoinService;
    
    @Autowired
    public BesoinController(final BesoinService besoinService ) {this.besoinService = besoinService;}

    /**
     * Api ENDPOINT GET liste des besoins
     * @return
     */
    @GetMapping("/besoins")
    @JsonView(MyJsonView.Besoin.class)
    public List<Besoin> showBesoin() {
        return this.besoinService.findAll();
    }

    /**
     * Api ENDPOINT GET liste des besoins par l'ID, pour retourner les informations d'un besoin
     * @param id
     * @return
     */
    @GetMapping("/besoins/{id}")
    @JsonView(MyJsonView.Besoin.class)
    public Besoin getEvt(@PathVariable int id) {
        return (Besoin) this.besoinService.findById(id);
    }


    /**
     * Api ENDPOINT PUT pour ajouter des besoins
     * @param besoins
     * @return
     */
    @PutMapping("/addBesoin")
    @JsonView(MyJsonView.Besoin.class)
    public Besoin addUsers(@RequestBody Besoin besoins) {
        return this.besoinService.save(besoins);
    }


    /**7
     *  Api ENDPOINT DELETE pour supprimer des besoins
     * @param id_bsn
     */
    @DeleteMapping("/besoins/{id_bsn}")
    @JsonView(MyJsonView.Besoin.class)
    public void delete(@PathVariable Integer id_bsn) {
        this.besoinService.delete(id_bsn);
    }
}
