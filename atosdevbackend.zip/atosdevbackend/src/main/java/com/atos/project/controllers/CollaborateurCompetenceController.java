package com.atos.project.controllers;

import com.atos.project.model.CollaborateurCompetence;
import com.atos.project.security.services.CollaborateurCompetenceService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@RestController
@CrossOrigin
public class CollaborateurCompetenceController {
    CollaborateurCompetenceService collaborateurCompetenceService;

    @Autowired
    public CollaborateurCompetenceController(final CollaborateurCompetenceService collaborateurCompetenceServiceService) {
        this.collaborateurCompetenceService = collaborateurCompetenceServiceService;
    }


    /**
     * Api ENDPOINT GET retourne une liste de collaborateurs
     * (Compétence)
     * @return
     */
    @GetMapping("/clb_cpc")
    @JsonView(MyJsonView.CollaborateurCompetence.class)
    public List<CollaborateurCompetence> showclb_cpc() {
        return this.collaborateurCompetenceService.findAll();
    }

    /**
     * Api ENDPOINT GET retourne une liste de collaborateurs
     * (Compétence par L'id)
     * @param id
     * @return
     */
    @GetMapping("/clb_cpc/{id}")
    @JsonView(MyJsonView.CollaborateurCompetence.class)
    public CollaborateurCompetence getclb_cpc(@PathVariable int id) {
        return (CollaborateurCompetence) this.collaborateurCompetenceService.findById(id);
    }

    /**
     * Api ENDPOINT PUT pour ajouter une compétence au collaborateur
     * @param collaborateurCompetence
     * @return
     */
    @PutMapping("/addclb_cpc")
    @JsonView(MyJsonView.CollaborateurCompetence.class)
    public CollaborateurCompetence addcollab(@RequestBody CollaborateurCompetence collaborateurCompetence) {
        return this.collaborateurCompetenceService.save(collaborateurCompetence);
    }

    /**
     * Api ENDPOINT DELETE pour supprimer une compétence au collaborateur
     * @param id
     */
    @DeleteMapping("/delclb_cpc/{id}")
    @JsonView(MyJsonView.CollaborateurCompetence.class)
    public void delete(@PathVariable int id) {
        this.collaborateurCompetenceService.delete(id);
    }
}
