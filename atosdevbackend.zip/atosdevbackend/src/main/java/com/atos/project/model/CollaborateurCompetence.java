package com.atos.project.model;

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
//import model.MyJsonView;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

@Entity
@Table(name = "collaborateur_competence")
@EntityListeners(AuditingEntityListener.class)
@IdClass(CollaborateurCompetence.PK.class)
public class CollaborateurCompetence {

	// les mappages de liaisons
	@Id
	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.REMOVE})
	@JoinColumn(name = "idClb", referencedColumnName = "id_clb")
	@JsonView({MyJsonView.CollaborateurCompetence.class})
	private Collaborateur collaborateur;

	@Id
	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
	@JoinColumn(name = "idCpc", referencedColumnName = "idCpc")
	@JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class})
	private Competence competence;

	@Id
	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
	@JoinColumn(name = "idExp", referencedColumnName = "id_exp")
	@JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class})
	private Experience experience;


	// les Getters et Setters
	public Competence getCompetence() {
		return competence;
	}
	public void setCompetence(Competence competence) {
		this.competence = competence;
	}
	public Experience getExperience() {
		return experience;
	}
	public void setExperience(Experience experience) {
		this.experience = experience;
	}
	public Collaborateur getCollaborateur() {
		return collaborateur;
	}
	public void setCollaborateur(Collaborateur collaborateur) {
		this.collaborateur = collaborateur;
	}

//	@Embeddable
	public static class PK implements Serializable {
		@JsonView({MyJsonView.CollaborateurCompetence.class})
//		@Column(name = "idClb")
		int collaborateur;
//		@Column(name = "idCpc")
		int competence;

		public int getCompetence() {
			return competence;
		}
		public void setCompetence(int competence) {
			this.competence = competence;
		}
		public int getCollaborateur() {
			return collaborateur;
		}
		public void setCollaborateur(int collaborateur) {
			this.collaborateur = collaborateur;
		}
	}

}
