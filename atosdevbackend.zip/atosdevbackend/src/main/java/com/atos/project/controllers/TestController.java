package com.atos.project.controllers;

import com.atos.project.model.User;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * origins * : pour tout autoriser
 * @RequestMapping : une autre variante de mappage url
 * maxAge = 3600 : la durée de mise en cache (ici définie à 30minutes)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class TestController {
	
	/**
	 * méthode de test avec un mapping autorisant tous les accès
	 * 
	 */
    @GetMapping("/all")
    public String allAccess() {
        return "Public Content.";
    }

    /**
	 * méthode de test avec un mapping autorisant les accès aux utilisateurs
	 * disposant d'un rôle utilisateur, modérateur, ou administrateur
	 * 
	 */
    @GetMapping("/user")
    @PreAuthorize("hasRole('USER') or hasRole('MODERATOR') or hasRole('ADMIN')")
    public String userAccess() {
        return "User Content.";
    }

    /**
	 * méthode de test avec un mapping autorisant les accès aux utilisateurs
	 * disposant d'un rôle modérateur
	 * 
	 */
    @GetMapping("/mod")
    @PreAuthorize("hasRole('MODERATOR')")
    public String moderatorAccess() {
        return "Moderator Board.";
    }

    /**
	 * méthode de test avec un mapping autorisant les accès aux utilisateurs
	 * disposant d'un rôle administrateur
	 * 
	 */
    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public String adminAccess() {
        return "Admin Board.";
    }

}
