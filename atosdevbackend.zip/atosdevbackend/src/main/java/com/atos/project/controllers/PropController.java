package com.atos.project.controllers;


import com.atos.project.model.Proposition;
import com.atos.project.security.services.PropService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@RestController
@CrossOrigin
public class PropController {
    
    PropService propService;
    
    public PropController(final PropService propService) {
        this.propService = propService;
        
    }

    /*******************************************************
     *                      Liste de propositions
     *******************************************************/
    @GetMapping("/propositions")
    @JsonView(MyJsonView.Proposition.class)
    public List<Proposition> showProposition() {
        return this.propService.findAll();
    }

    @GetMapping("/propositions/{id}")
    @JsonView(MyJsonView.Proposition.class)
    public Proposition getprop(@PathVariable int id) {
        return (Proposition) this.propService.findById(id);
    }


    /*******************************************************
     *                     Ajout de proposition
     *******************************************************/
    @PutMapping("/addProposition")
    @JsonView(MyJsonView.Proposition.class)
    public Proposition addprop(@RequestBody Proposition propositions) {
        return this.propService.save(propositions);
    }

    /******************************************************
     *                      Suppression de proposition
     *******************************************************/

    @DeleteMapping("/propositions/{id}")
    @JsonView(MyJsonView.Proposition.class)
    public void delete(@PathVariable int id) {
        this.propService.delete(id);
    }
}
