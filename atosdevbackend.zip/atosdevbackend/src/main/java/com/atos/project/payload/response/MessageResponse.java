package com.atos.project.payload.response;

/**
 * Cette classe sert aux échanges des Datas entre Spring et Angular
 * 
 * @author-JavaDoc Christophe
 *
 */

public class MessageResponse {

    private String message;

    public MessageResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

