package com.atos.project.payload.response;

/**
 * Cette classe peut servir pour renvoyer un message personnalisé à l'utilisateur dans un contexte préalablement défini
 * 
 * @author-JavaDoc Christophe
 *
 */

public class MessageResponse {

    private String message;

    public MessageResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

