package com.atos.project.model;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name="agence")
@EntityListeners(AuditingEntityListener.class)
public class Agence {
	// les attributs
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class})
    private int idAgc;
    @Column(unique = true)
    @JsonView({MyJsonView.SiteClient.class,MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class})
    private String lib;

    // le mappage de liaison
    // une agence peut avoir un ou plusieurs collaborateurs (et un collaborateur n'est rattaché qu'à une seule et unique agence)
    @OneToMany(mappedBy="agence",fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH}, targetEntity = Collaborateur.class)
    @JsonView(MyJsonView.SiteClient.class)
    private List<Collaborateur> collab = new ArrayList<>();

    // le constructeur par défaut est non codé, il est généré implicitement par l'IDE
    
    
    // les Getters et Setters
    public Integer getId() {
        return idAgc;
    }
    public void setId(Integer id) { this.idAgc = idAgc; }
    public String getLib() {
        return lib;
    }
    public void setLib(String lib) {
        this.lib = lib;
    }

    public int getIdAgc() {
        return idAgc;
    }

    public void setIdAgc(int idAgc) {
        this.idAgc = idAgc;
    }

    public List<Collaborateur> getCollab() {
        return collab;
    }

    public void setCollab(List<Collaborateur> collab) {
        this.collab = collab;
    }
}
