package com.atos.project.security.services;

import com.atos.project.model.ContactClient;
import com.atos.project.repository.ContactRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Nos classes de Services servent toutes à assurer la liaison entre le contrôleur d'une entité donnée
 * et son entité Repository (qui hérite de JPA) - Ceci afin de remonter vers la Base De Données (BDD),
 * pour assurer la communication DAO,
 * et pouvoir utiliser les requêtes ORM
 * 
 * findAll() : méthode CRUD-ORM pour récupérer une liste d'une entité
 * save() : méthode CRUD-ORM pour un ajout (cas du PostMapping) ou pour une modification (cas du PutMapping)
 * findById() : méthode CRUD-ORM pour récupérer les informations détaillées sur une entité donnée
 * deleteById() : méthode CRUD-ORM pour supprimer une entité
 * 
 * @author-JavaDoc Christophe
 *
 */

@Service
public class ContactService {

    @Autowired
    ContactRepo contactRepo;

    /*Lister tous les contact-clients*/
    public List<ContactClient> getAll() {
        return this.contactRepo.findAll();
    }

    public ContactClient addClient(ContactClient clients) {
        return this.contactRepo.save(clients);
    }

    public ContactClient findById(Integer id) {
        return this.contactRepo.findById(id).get();
    }

    public List<ContactClient> findAll() {
        return this.contactRepo.findAll();
    }

    public ContactClient save(ContactClient clients) {
        return this.contactRepo.save(clients);
    }

    public void delete(Integer id) {
        this.contactRepo.deleteById(id);
    }
}
