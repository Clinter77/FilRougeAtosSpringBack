package com.atos.project.controllers;

import com.atos.project.model.Competence;
import com.atos.project.security.services.CompetenceService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@CrossOrigin
@RestController
public class CompetenceController {
    
    CompetenceService competenceService;
    
    @Autowired
    public CompetenceController(final CompetenceService competenceService) {
        this.competenceService = competenceService;
    }

    /**
     * Api Endpoint url Get - retourne une liste de compétences
     * @return
     */
    @GetMapping("/competences")
    @JsonView(MyJsonView.Competence.class)
    public List<Competence> showCompetence() {
        return this.competenceService.findAll();
    }

    /**
     * Api Endpoint url Get - retourne une compétence avec l'id
     * @param id
     * @return
     */
    @GetMapping("/competences/{id}")
    @JsonView(MyJsonView.Competence.class)
    public Competence getcomp(@PathVariable int id) {
        return (Competence) this.competenceService.findById(id);
    }

    /**
     * Api Endpoint url PUT - pour ajouter une compétence
     * @param competences
     * @return
     */
    @PutMapping("/addcomp")
    @JsonView(MyJsonView.Competence.class)
    public Competence addcomp(@RequestBody Competence competences) {
        return this.competenceService.save(competences);
    }


    /**
     * Api Endpoint url DELETE - pour supprimer une compétence
     * @param id
     */
    @DeleteMapping("/delcomp/{id}")
    @JsonView(MyJsonView.Competence.class)
    public void delete(@PathVariable int id) {
        this.competenceService.delete(id);
    }
}
