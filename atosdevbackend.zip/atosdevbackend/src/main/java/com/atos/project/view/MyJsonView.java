package com.atos.project.view;

public class MyJsonView {
    public static class Collaborateur{};
    public static class CollaborateurCompetence{};
    public static class Contact{};

    public static class Utilisateur{};
    public static class Proposition{};

    public static class Besoin{};
    public static class BesoinCompetence{};
    public static class Client{};
    public static class SiteClient{};
    public static class Demarche{};
    public static class Competence{};
    public static class Experience{};


}
