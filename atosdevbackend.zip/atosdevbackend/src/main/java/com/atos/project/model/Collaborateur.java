package com.atos.project.model;

import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

/**
 * @Entity : déclaration de l'entité
 * @Table : déclaration de la table
 * @EntityListeners : pour la création automatique de la table (grâce à JPA - Java Persistence Api, l'ORM Object Relationship Managment de Spring)
 * @Id : définition de la clé primaire
 * @GeneratedValue : pour l'auto-incrémentation
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @Column : Définition de la colonne
 * @Column(unique = true) : pour ajouter une contrainte d'unicité sur ce champ
 * @Temporal(TemporalType.DATE) : pour les champs de type date
 * @OneToMany : mappage de la clé étrangère (relation de un à plusieurs) 
 * @OneToOne : mappage de la clé étrangère (relation de un à un)
 * @ManyToOne : mappage de la clé étrangère (relation de plusieurs à un)
 * @ManyToMany : mappage de la clé étrangère (relation de plusieurs à plusieurs)
 * FetchType.EAGER - FetchType.LAZY :
 *    Le chargement EAGER d'une collection signifie que tous les éléments enfants sont récupérés au moment de l'appel
 *    de la table parente, ce qui peut générer un temps assez long s'il y a beaucoup de données sur la table enfant,
 *    il est donc parfois préférable d'opter pour un chargement dit "paresseux", donc en Lazy, où les éléments de la
 *    seconde table seront chargés et affichés au fur et à mesure (et non tous chargés dans un premier temps, puis ensuite affichés).
 * CascadeType : l'ordre des types choisis est important.
 * CascadeType.PERSIST : Ce type permet de sauvegarder l'opération en cascade vers l'entité associée.
 * CascadeType.MERGE : Les entités associées sont fusionnées lorsque l'entité propriétaire l'est.
 * CascadeType.REFRESH : Pour le rafraîchissement, l'actualisation.
 * 
 */

@Entity
@Table(name="Collaborateur")
@EntityListeners(AuditingEntityListener.class)
public class Collaborateur {
	// les attributs
    @Id
    @Column(name="id_clb")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class, MyJsonView.Proposition.class})
    private Integer idClb;

    // @NotBlank : ce champ n'accepte pas de valeur nulle 
    @NotBlank
    @Size(max = 100)
    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private String nom;

    @NotBlank
    @Size(max = 100)
    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private String prenom;

    @Size(max = 50)
    @Email
    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private String email;

    @NotBlank
    @Size(max = 50)
    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private String Identifiant_Dass;

    // les mappages de liaisons
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name = "idAgc")
    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private Agence agence;

    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private boolean f_dispo;

    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private float bench;

    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private String tel;

    @JsonView({MyJsonView.Collaborateur.class,MyJsonView.CollaborateurCompetence.class,MyJsonView.Proposition.class})
    private boolean f_actif;

    @OneToMany(mappedBy="collaborateur",fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH}, targetEntity = CollaborateurCompetence.class,  orphanRemoval = true)
    @JsonView({MyJsonView.Collaborateur.class})
    private List<CollaborateurCompetence> listeCollaborateurCompetence = new ArrayList<>();

    // les Getters et Setters
    public Integer getIdClb() {
        return idClb;
    }

    public void setIdClb(Integer idClb) {
        this.idClb = idClb;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentifiant_Dass() {
        return Identifiant_Dass;
    }

    public void setIdentifiant_Dass(String identifiant_Dass) {
        Identifiant_Dass = identifiant_Dass;
    }

    public Agence getAgence() {
        return agence;
    }

    public void setAgence(Agence agence) {
        this.agence = agence;
    }

    public boolean isF_dispo() {
        return f_dispo;
    }

    public void setF_dispo(boolean f_dispo) {
        this.f_dispo = f_dispo;
    }

    public boolean isF_actif() {
        return f_actif;
    }

    public void setF_actif(boolean f_actif) {
        this.f_actif = f_actif;
    }

    public float getBench() {
        return bench;
    }

    public void setBench(float bench) {
        this.bench = bench;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public List<CollaborateurCompetence> getListeCollaborateurCompetence() {
        return listeCollaborateurCompetence;
    }

    public void setListeCollaborateurCompetence(List<CollaborateurCompetence> listeCollaborateurCompetence) {
        this.listeCollaborateurCompetence = listeCollaborateurCompetence;
    }


}
