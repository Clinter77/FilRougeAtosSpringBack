package com.atos.project.controllers;

import com.atos.project.model.Collaborateur;
import com.atos.project.security.services.CollaborateurCompetenceService;
import com.atos.project.security.services.CollaborateurService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@RestController
@CrossOrigin
public class CollaborateurController {

    CollaborateurService collaborateurService;

    @Autowired
    public CollaborateurController(final CollaborateurService collaborateurService) {
        this.collaborateurService = collaborateurService;
    }

    /**
     * Api ENDPOINT GET - pour obtenir une liste de collaborateurs
     * @return
     */
    @GetMapping("/clb")
    @JsonView(MyJsonView.Collaborateur.class)
    public List<Collaborateur> showCollaborateur() {
        return this.collaborateurService.findAll();
    }

    /**
     * RestApi Contrôleur url Get - pour ajouter un collaborateur avec son id
     * @param id
     * @return
     */
    @GetMapping("/clb/{id}")
    @JsonView(MyJsonView.Collaborateur.class)
    public Collaborateur getCollab(@PathVariable int id) {
        return (Collaborateur) this.collaborateurService.findById(id);
    }

    /**
     * RestApi Contrôleur url PUT - pour ajouter un collaborateur
     * @param collaborateur
     * @return
     */
    @PutMapping("/addclb")
    public Collaborateur addcollab(@RequestBody Collaborateur collaborateur) {
        collaborateur = this.collaborateurService.save(collaborateur);
        if (collaborateur.getListeCollaborateurCompetence().size() > 0) {
            Collaborateur finalCollaborateur = collaborateur;
            collaborateur.getListeCollaborateurCompetence().stream().forEach(collaborateurCompetence -> {
                collaborateurCompetence.setCollaborateur(finalCollaborateur);
            });
        }
        return this.collaborateurService.save(collaborateur);
    }

    /**
     * Api Endpoint url DELETE - pour supprimer un collaborateur par son ID
     * @param id
     */
    @DeleteMapping("/delclb/{id}")
    public void delete(@PathVariable int id) {

        this.collaborateurService.delete(id);
    }
}
