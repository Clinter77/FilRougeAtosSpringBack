package com.atos.project.security.services;

import com.atos.project.model.StatutProposition;
import com.atos.project.model.StatutProposition;
import com.atos.project.repository.StatutRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Nos classes de Services servent toutes à assurer la liaison entre le contrôleur d'une entité donnée
 * et son entité Repository (qui hérite de JPA) - Ceci afin de remonter vers la Base De Données (BDD),
 * pour assurer la communication DAO,
 * et pouvoir utiliser les requêtes ORM
 * 
 * findAll() : méthode CRUD-ORM pour récupérer une liste d'une entité
 * save() : méthode CRUD-ORM pour un ajout (cas du PostMapping) ou pour une modification (cas du PutMapping)
 * findById() : méthode CRUD-ORM pour récupérer les informations détaillées sur une entité donnée
 * deleteById() : méthode CRUD-ORM pour supprimer une entité
 * 
 * @author-JavaDoc Christophe
 *
 */

@Service
public class StatutPropService {
    
    @Autowired
    StatutRepo statutRepo;
    
    // Lister les propositions 
    public List<StatutProposition> getAll() {
        return this.statutRepo.findAll();
    }

    public StatutProposition addStatutProposition(StatutProposition Statut) {
        return this.statutRepo.save(Statut);
    }

    public StatutProposition findById(Integer id) {
        return this.statutRepo.findById(id).get();
    }

    public List<StatutProposition> findAll() {
        return this.statutRepo.findAll();
    }

    public StatutProposition save(StatutProposition Statut) {
        return this.statutRepo.save(Statut);
    }

    public void delete(Integer id) {
        this.statutRepo.deleteById(id);
    }
}
