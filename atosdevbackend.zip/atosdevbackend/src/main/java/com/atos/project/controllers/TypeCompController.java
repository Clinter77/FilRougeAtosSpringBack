package com.atos.project.controllers;

import com.atos.project.model.TypeCompetence;
import com.atos.project.security.services.TypeCompetenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@RestController
@CrossOrigin
public class TypeCompController {

    TypeCompetenceService typeCompetenceService;

    @Autowired
    public TypeCompController(final TypeCompetenceService typeCompetenceService ) {this.typeCompetenceService = typeCompetenceService;}

    /*******************************************************
     *                Liste des types de compétence
     *******************************************************/
    @GetMapping("/tcp")
    public List<TypeCompetence> showTypeCompetenceService() {
        return this.typeCompetenceService.findAll();
    }

    @GetMapping("/tcp/{id}")
    public TypeCompetence getEvt(@PathVariable int id) {
        return (TypeCompetence) this.typeCompetenceService.findById(id);
    }


    /*******************************************************
     *                     Ajout d'un type de compétence
     *******************************************************/
    @PutMapping("/addtcp")
    public TypeCompetence addtcp(@RequestBody TypeCompetence typeCompetence) {
        return this.typeCompetenceService.save(typeCompetence);
    }

    /******************************************************
     *                Suppression d'un type de compétence
     *******************************************************/

    @DeleteMapping("/tcps/{id}")
    public void delete(@PathVariable int id) {
        this.typeCompetenceService.delete(id);
    }
}
