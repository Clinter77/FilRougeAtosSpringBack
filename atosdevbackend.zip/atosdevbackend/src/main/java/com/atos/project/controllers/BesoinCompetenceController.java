package com.atos.project.controllers;

import com.atos.project.model.BesoinCompetence;
import com.atos.project.security.services.BesoinCompetenceService;
import com.atos.project.view.MyJsonView;
import com.fasterxml.jackson.annotation.JsonView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @RestController : déclaration de cette Classe comme étant contrôleur de Web Services - et sans utilisation de système de Template
 * @CrossOrigin : pour autoriser des requêtes provenant d'autres serveurs (les ressources de l'API se situent sur plusieurs Serveurs)
 *                requêtes multi-domaines - partage de ressources d'origines croisées (CORS)
 * @Autowired : le paramètre du constructeur est une injection de dépendances
 * @GetMapping : le mappage url via la méthode Get (la méthode Get est bien plus limitée dans la quantité de données transmissibles que la méthode Post)
 * @JsonView : pour pouvoir filtrer les résultats (les vues JsonView) qui apparaîtront dans les résultats de requêtes (et éviter ainsi les doublons - les erreurs de redondance cyclique)
 * @PutMapping : pour permettre l'insertion des Data via mapping
 * @DeleteMapping : pour permettre la suppression de Data via mapping
 * 
 */

@RestController
@CrossOrigin
public class BesoinCompetenceController {
    BesoinCompetenceService besoinCompetenceService;

    @Autowired
    public BesoinCompetenceController(final BesoinCompetenceService besoinCompetenceServiceService) {
        this.besoinCompetenceService = besoinCompetenceServiceService;
    }

    /**
     * Api Endpoint GET Pour lister les besoins D'un clients
     * @return
     */
    @GetMapping("/bsn_cpc")
    @JsonView(MyJsonView.BesoinCompetence.class)
    public List<BesoinCompetence> showclb_cpc() {
        return this.besoinCompetenceService.findAll();
    }

    /**
     * Api Endpoint GET Pour lister les besoins en compétences d'un client
     * par son attribut ID
     * @param id
     * @return
     */
    @GetMapping("/bsn_cpc/{id}")
    @JsonView(MyJsonView.BesoinCompetence.class)
    public BesoinCompetence getclb_cpc(@PathVariable int id) {
        return (BesoinCompetence) this.besoinCompetenceService.findById(id);
    }

    /**
     * Api EndPoint PUT pour ajouter un besoin de compétence
     * @param besoinCompetence
     * @return
     */
    @PutMapping("/addbsn_cpc")
    @JsonView(MyJsonView.BesoinCompetence.class)
    public BesoinCompetence addcollab(@RequestBody BesoinCompetence besoinCompetence) {
        return this.besoinCompetenceService.save(besoinCompetence);
    }


    /**
     * Api EndPoint DELETE pour supprimer un besoin de compétence
     * @param id
     */
    @DeleteMapping("/delbsn_cpc/{id}")
    @JsonView(MyJsonView.BesoinCompetence.class)
    public void delete(@PathVariable int id) {
        this.besoinCompetenceService.delete(id);
    }
    
}
