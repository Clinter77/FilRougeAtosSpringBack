package com.atos.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtosDevBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
